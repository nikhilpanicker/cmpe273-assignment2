package hello

import org.springframework.data.mongodb.repository.MongoRepository
//remove if not needed

trait CustomerRepository extends MongoRepository[UserCreation, String] {

 // def findByFirstName(firstName: String): UserCreation
 def findByemail(email: String): UserCreation

 // def findByLastName(lastName: String): List[UserCreation]
}